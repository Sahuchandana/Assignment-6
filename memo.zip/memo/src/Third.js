import React, { useState, useCallback, memo } from 'react';

const CounterButton = memo(({ onClick, children }) => {
  console.log(`Rendering button: ${children}`);
  return (
    <button onClick={onClick}>
      {children}
    </button>
  );
});

function Butt3() {
  const [count, setCount] = useState(0);

  const increment = useCallback(() => {
    setCount(prevCount => prevCount + 1);
  }, []);

  const decrement = useCallback(() => {
    setCount(prevCount => prevCount - 1);
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <h1>Button Click Counter</h1>
        <p>Count: {count}</p>
        <CounterButton onClick={increment}>Increment</CounterButton>
        <CounterButton onClick={decrement}>Decrement</CounterButton>
      </header>
    </div>
  );
}

export default Butt3;