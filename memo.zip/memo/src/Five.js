import React, { useReducer } from "react";

const initialState = false;

function toggleReducer(state) {
  return !state;
}

const ToggleSwitch = () => {
  const [isOn, dispatch] = useReducer(toggleReducer, initialState);

  return (
    <div style= {{textAlign: "center"}}>
      <h2>Switch</h2>
      <button
        onClick={() => dispatch()}
        style={{
          backgroundColor: isOn ? "green" : "red",
          color: "white",
          padding: "10px 20px",
          border: "none",
          cursor: "pointer",
        }}
      >
        {isOn ? "ON" : "OFF"}
      </button>
    </div>
  );
};

export default ToggleSwitch;