import React, { useState, useMemo } from 'react';
function Sort4() {
  const [numbers, setNumbers] = useState([34, 7, 23, 32, 5, 62]);
  const [sortOrder, setSortOrder] = useState('ascending');
  const sortedNumbers = useMemo(() => {
    console.log('Sorting the list...');
    const sorted = [...numbers];
    sorted.sort((a, b) => (sortOrder === 'ascending' ? a - b : b - a));
    return sorted;
  }, [numbers, sortOrder]);
  const toggleSortOrder = () => {
    setSortOrder((prevOrder) => (prevOrder === 'ascending' ? 'descending' : 'ascending'));
  };
  return (
    <div className="App">
      <header className="App-header">
        <h1>Sorting a List using useMemo</h1>
        <button onClick={toggleSortOrder}>
          Sort {sortOrder === 'ascending' ? 'Descending' : 'Ascending'}
        </button>
        <ul>
          {sortedNumbers.map((num, index) => (
            <li key={index}>{num}</li>
          ))}
        </ul>
      </header>
    </div>
  );
}
export default Sort4;