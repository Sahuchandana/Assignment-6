// 1st
import React, { useState, useMemo } from 'react';
import Second from './Second';
import Third from './Third';
import Four from './Four';
import Five from './Five';
import Six from './Six';
function SquareCalculator() {
  const [number, setNumber] = useState(0);
  const [renderCount, setRenderCount] = useState(0);
  const square = useMemo(() => {
    console.log('Calculating square...');
    return number * number;
  }, [number]); 
  const incrementRenderCount = () => {
    setRenderCount(renderCount + 1);
  };
  return (
    <div>
      <p>Square of a Number: {renderCount}</p>
      <input
        type="number"
        value={number}
        onChange={(e) => {
          setNumber(Number(e.target.value)); 
          incrementRenderCount(); 
        }} />
      <p>Square of {number} is: {square}</p>
      <div>
        <Second></Second>
        <hr></hr>
      </div>
      <div>
        <Third></Third>
        <hr></hr>
      </div>
      <div>
        <Four></Four>
        <hr></hr>
      </div>
      <div>
        <Five></Five>
        <hr></hr>
      </div>
      <div>
        <Six></Six>
        <hr></hr>
      </div>
    </div>
  );
}
export default SquareCalculator;

