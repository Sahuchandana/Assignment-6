import React, { useState, useCallback } from "react";
const ChildButton = React.memo(({ onClick, label }) => {
  return <button onClick={onClick}style={{ margin: "5px" }}>{label}</button>;
});
const ParentComponent = () => {
  const [count, setCount] = useState(0);
  const handleAdd = useCallback(() => {
    setCount((prevCount) => prevCount + 1);
  }, []);
  const handleSubtract = useCallback(() => {
    setCount((prevCount) => prevCount - 1);
  }, []);
  return (
    <div style= {{textAlign: "center"}}>
      <h2>Counter: {count}</h2>
      <ChildButton onClick={handleAdd} label="Add" />
      <ChildButton onClick={handleSubtract} label="Subtract" />
    </div>
  );
};

export default ParentComponent;